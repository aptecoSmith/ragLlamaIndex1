# Introduction

### What is an audience?

An audience refers to a specific group of individuals or companies. These individuals share common characteristics, interests, or behaviours, that make them relevant and receptive to marketing efforts. Orbit allows you to better understand your audience and target them for marketing campaigns or messages.

An audience can be defined and segmented based on various characteristics, such as:

- Demographics (age, gender, location, income)
- Psychographics (interests, attitudes, lifestyle)
- Behaviour (purchase history, browsing habits, engagement with previous campaigns)
- Or a combination of these factors

Orbit provides a very flexible and powerful way of defining your audience, allowing you to combine these factors in many ways. 

You can define your audience via the **Audience** tab:

![Untitled](Introduction%20559c8ca79638441d81dffe5d6a2e6a34/Untitled.png)
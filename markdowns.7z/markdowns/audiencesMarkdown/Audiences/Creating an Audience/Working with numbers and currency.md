# Working with numbers and currency

Numbers and currency can be used to filter your audience. You can choose to include or exclude numbers in these ranges.

![Untitled](Working%20with%20numbers%20and%20currency%2095c03a749655489eb0a7803938d753f5/Untitled.png)

Here, you can specify a number of ranges to match against here. You can choose:

- A range, like less than one thousand
- A band, like greater than one thousand, and less than or equal to five thousand

![Untitled](Working%20with%20numbers%20and%20currency%2095c03a749655489eb0a7803938d753f5/Untitled%201.png)

A range adds a new section to your audience. The values can then be edited here, or the section can be deleted.

![Untitled](Working%20with%20numbers%20and%20currency%2095c03a749655489eb0a7803938d753f5/Untitled%202.png)
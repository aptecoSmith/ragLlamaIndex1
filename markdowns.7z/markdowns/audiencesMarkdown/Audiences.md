# Audiences

[Introduction](Audiences%20621a4e170eb4428d90595ec3abf53d40/Introduction%20559c8ca79638441d81dffe5d6a2e6a34.md)

[Creating an Audience](Audiences%20621a4e170eb4428d90595ec3abf53d40/Creating%20an%20Audience%20d3f46d802a9f447b91f091cea429c8e9.md)
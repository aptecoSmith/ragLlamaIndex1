# Audience Workbooks Initial Release

[**Audience workbooks: Benefits**](Audience%20Workbooks%20Initial%20Release%20257dbf3dda284440b542b124c4e64521/Audience%20workbooks%20Benefits%20bca544b832c64836a211097a48bd36d5.md)

[Audience workbooks: Introduction](Audience%20Workbooks%20Initial%20Release%20257dbf3dda284440b542b124c4e64521/Audience%20workbooks%20Introduction%20a2312d41a2ee4c81b31a34cde00a2135.md)

[Audience workbooks: New item](Audience%20Workbooks%20Initial%20Release%20257dbf3dda284440b542b124c4e64521/Audience%20workbooks%20New%20item%202f4dd6d538ec4177a74f57fd6a3da273.md)

[Audience workbooks: Favourites](Audience%20Workbooks%20Initial%20Release%20257dbf3dda284440b542b124c4e64521/Audience%20workbooks%20Favourites%20b4593cabc2a24a54b606328abded8947.md)

[Audience workbooks: Solutions](Audience%20Workbooks%20Initial%20Release%20257dbf3dda284440b542b124c4e64521/Audience%20workbooks%20Solutions%20f6d55b87eadf4088a944346d1855e5cb.md)
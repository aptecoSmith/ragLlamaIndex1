# Audience workbooks: New item

The new item page is central to how workbooks function. It allows you to add new visualisations via the Favourites and Solutions sub menus.

![Untitled](Audience%20workbooks%20New%20item%202f4dd6d538ec4177a74f57fd6a3da273/Untitled.png)

##
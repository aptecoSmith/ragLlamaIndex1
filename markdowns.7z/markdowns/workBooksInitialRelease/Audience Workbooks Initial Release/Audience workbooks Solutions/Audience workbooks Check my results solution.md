# Audience workbooks: Check my results solution

This solution guides you through creating a set of visualisations. These visualisations are used to sense check that the records in the audience are as expected.

To create a new check panel:

1. Find the **Check My Results** solution on the Add New page.
2. Click **Add**. You are now asked to provide a name.
    
    ![Untitled](Audience%20workbooks%20Check%20my%20results%20solution%20ed40bc3cd79a4c00addb9ccf465c0f2d/Untitled.png)
    
    <aside>
    💡 **Note**: The check panel is comprised of a set of visualisations and a grid of data. The style of visualisation is chosen automatically depending on the number of categories in the data.
    
    </aside>
    
3. You can choose to have Orbit create the visualisations for you from your audience by choosing **Auto Generated**. 
4. You can select your own visualisations and grid columns by selecting **Manual**.
    
    ![Untitled](Audience%20workbooks%20Check%20my%20results%20solution%20ed40bc3cd79a4c00addb9ccf465c0f2d/Untitled%201.png)
    
5. A new check panel is added to your workbook, as per below.

![Untitled](Audience%20workbooks%20Check%20my%20results%20solution%20ed40bc3cd79a4c00addb9ccf465c0f2d/Untitled%202.png)

To re-use this check panel on another audience, or to share it with other users, add a favourite by clicking the star icon in the top right. A new favourite is then added to your Add New page and you can re-use it and share it on from there.
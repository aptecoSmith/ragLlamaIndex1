# Audience workbooks: Export data solution

This section guides you through the steps required to set up a datagrid to export records via File Transfer Protocol (FTP), or a downstream channel.

### Export solution

To select settings:

1. Choose the **Table** that contains the records to display.
2. Choose the **Delivery Channel** for the export.

![Untitled](Audience%20workbooks%20Export%20data%20solution%2082bd5f886b6e4238908130e9d7959991/Untitled.png)

To select columns:

1. Choose the **Columns** to be exported.
2. Reorder the **Columns** as required.

<aside>
💡 **Note**: Some columns cannot be removed as they are required in the export.

</aside>

![Untitled](Audience%20workbooks%20Export%20data%20solution%2082bd5f886b6e4238908130e9d7959991/Untitled%201.png)

A new export tab is added to your workbook.

![Untitled](Audience%20workbooks%20Export%20data%20solution%2082bd5f886b6e4238908130e9d7959991/Untitled%202.png)

This Grid View displays multiple rows of data. Use the **View as** option in the top right to switch to Page View, displaying a single record at a time.

![Untitled](Audience%20workbooks%20Browse%20data%20solution%202195bf91e302442bbbb6533dc0d88eee/Untitled%203.png)

If you are happy with this datagrid and would like to use it again or share it, then add it to your favourites using the star in the top right. You can then access it from the Add New page from where it can be shared.
# Audience workbooks: Solutions

Solutions guide you in accomplishing specific tasks through step-by-step instructions, enabling the creation of visualisations with preset configurations. This approach not only enhances learning but also prevents the creation of empty or blank visualisations.

[Audience workbooks: Check my results solution](Audience%20workbooks%20Solutions%20f6d55b87eadf4088a944346d1855e5cb/Audience%20workbooks%20Check%20my%20results%20solution%20ed40bc3cd79a4c00addb9ccf465c0f2d.md)

[Audience workbooks: Browse data solution](Audience%20workbooks%20Solutions%20f6d55b87eadf4088a944346d1855e5cb/Audience%20workbooks%20Browse%20data%20solution%202195bf91e302442bbbb6533dc0d88eee.md)

[Audience workbooks: Export data solution](Audience%20workbooks%20Solutions%20f6d55b87eadf4088a944346d1855e5cb/Audience%20workbooks%20Export%20data%20solution%2082bd5f886b6e4238908130e9d7959991.md)